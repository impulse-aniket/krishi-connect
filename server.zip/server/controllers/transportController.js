const TransportRequest = require(
  "../models/TransportRequest"
);

const Order = require("../models/Order");

const Vehicle = require(
  "../models/Vehicle"
);

// CREATE TRANSPORT REQUEST
const createTransportRequest = async (
  req,
  res
) => {
  try {
    if (req.user.role !== "farmer") {
      return res.status(403).json({
        message:
          "Only farmers can request transport",
      });
    }

    const {
      orderId,
      pickupLocation,
      deliveryLocation,
      requestedDate,
      transportCost,
      notes,
    } = req.body;

    if (
      !orderId ||
      !pickupLocation ||
      !deliveryLocation ||
      !requestedDate
    ) {
      return res.status(400).json({
        message:
          "Please provide all transport details",
      });
    }

    const order =
      await Order.findOne({
        _id: orderId,
        farmer: req.user.id,
      }).populate("crop");

    if (!order) {
      return res.status(404).json({
        message: "Order not found",
      });
    }

    if (
      order.status === "cancelled"
    ) {
      return res.status(400).json({
        message:
          "Transport cannot be requested for a cancelled order",
      });
    }

    const existingRequest =
      await TransportRequest.findOne({
        order: orderId,
        status: {
          $in: [
            "pending",
            "accepted",
          ],
        },
      });

    if (existingRequest) {
      return res.status(400).json({
        message:
          "Transport has already been requested for this order",
      });
    }

    const request =
      await TransportRequest.create({
        order: order._id,
        farmer: req.user.id,
        pickupLocation,
        deliveryLocation,
        quantity: order.quantity,
        unit: order.crop.unit,
        requestedDate,
        transportCost:
          transportCost || 0,
        notes: notes || "",
      });

    const populatedRequest =
      await TransportRequest.findById(
        request._id
      )
        .populate(
          "order",
          "quantity pricePerUnit totalAmount status"
        )
        .populate(
          "farmer",
          "name email phone location"
        );

    res.status(201).json({
      message:
        "Transport request created successfully",
      request: populatedRequest,
    });
  } catch (error) {
    console.error(
      "Create Transport Request Error:",
      error.message
    );

    res.status(500).json({
      message:
        "Server error while creating transport request",
    });
  }
};

// GET FARMER TRANSPORT REQUESTS
const getFarmerTransportRequests =
  async (req, res) => {
    try {
      if (req.user.role !== "farmer") {
        return res.status(403).json({
          message:
            "Only farmers can view their transport requests",
        });
      }

      const requests =
        await TransportRequest.find({
          farmer: req.user.id,
        })
          .populate(
            "order",
            "quantity pricePerUnit totalAmount status"
          )
          .populate(
            "provider",
            "name phone location"
          )
          .populate(
            "vehicle",
            "vehicleNumber vehicleType capacity unit"
          )
          .sort({ createdAt: -1 });

      res.status(200).json({
        count: requests.length,
        requests,
      });
    } catch (error) {
      console.error(
        "Get Farmer Transport Requests Error:",
        error.message
      );

      res.status(500).json({
        message:
          "Server error while fetching transport requests",
      });
    }
  };

// GET PROVIDER REQUESTS
const getProviderRequests =
  async (req, res) => {
    try {
      if (
        req.user.role !==
        "transportProvider"
      ) {
        return res.status(403).json({
          message:
            "Only transport providers can view transport requests",
        });
      }

      const requests =
        await TransportRequest.find({
          status: "pending",
        })
          .populate(
            "order",
            "quantity pricePerUnit totalAmount status"
          )
          .populate(
            "farmer",
            "name email phone location"
          )
          .sort({ createdAt: -1 });

      res.status(200).json({
        count: requests.length,
        requests,
      });
    } catch (error) {
      console.error(
        "Get Provider Requests Error:",
        error.message
      );

      res.status(500).json({
        message:
          "Server error while fetching transport requests",
      });
    }
  };

// GET MY PROVIDER REQUESTS
const getProviderAssignments =
  async (req, res) => {
    try {
      if (
        req.user.role !==
        "transportProvider"
      ) {
        return res.status(403).json({
          message:
            "Only transport providers can view assignments",
        });
      }

      const requests =
        await TransportRequest.find({
          provider: req.user.id,
        })
          .populate(
            "order",
            "quantity pricePerUnit totalAmount status"
          )
          .populate(
            "farmer",
            "name email phone location"
          )
          .populate(
            "vehicle",
            "vehicleNumber vehicleType capacity unit"
          )
          .sort({ createdAt: -1 });

      res.status(200).json({
        count: requests.length,
        requests,
      });
    } catch (error) {
      console.error(
        "Get Provider Assignments Error:",
        error.message
      );

      res.status(500).json({
        message:
          "Server error while fetching assignments",
      });
    }
  };

// ACCEPT TRANSPORT REQUEST
const acceptTransportRequest =
  async (req, res) => {
    try {
      if (
        req.user.role !==
        "transportProvider"
      ) {
        return res.status(403).json({
          message:
            "Only transport providers can accept requests",
        });
      }

      const {
        vehicleId,
      } = req.body;

      if (!vehicleId) {
        return res.status(400).json({
          message:
            "Please select a vehicle",
        });
      }

      const request =
        await TransportRequest.findOne({
          _id: req.params.id,
          status: "pending",
        });

      if (!request) {
        return res.status(404).json({
          message:
            "Transport request not found or already processed",
        });
      }

      const vehicle =
        await Vehicle.findOne({
          _id: vehicleId,
          provider: req.user.id,
          status: "available",
        });

      if (!vehicle) {
        return res.status(404).json({
          message:
            "Available vehicle not found",
        });
      }

      const capacityInSameUnit =
        vehicle.capacity;

      if (
        capacityInSameUnit <
        request.quantity
      ) {
        return res.status(400).json({
          message:
            "Vehicle capacity is insufficient for this request",
        });
      }

      request.provider =
        req.user.id;

      request.vehicle =
        vehicle._id;

      request.status = "accepted";

      request.deliveryStatus =
        "pickup_pending";

      await request.save();

      vehicle.status = "busy";

      await vehicle.save();

      await Order.findByIdAndUpdate(
        request.order,
        {
          deliveryStatus: "pending",
        }
      );

      res.status(200).json({
        message:
          "Transport request accepted successfully",
        request,
      });
    } catch (error) {
      console.error(
        "Accept Transport Request Error:",
        error.message
      );

      res.status(500).json({
        message:
          "Server error while accepting transport request",
      });
    }
  };

// REJECT TRANSPORT REQUEST
const rejectTransportRequest =
  async (req, res) => {
    try {
      if (
        req.user.role !==
        "transportProvider"
      ) {
        return res.status(403).json({
          message:
            "Only transport providers can reject requests",
        });
      }

      const request =
        await TransportRequest.findOne({
          _id: req.params.id,
          status: "pending",
        });

      if (!request) {
        return res.status(404).json({
          message:
            "Transport request not found",
        });
      }

      request.status = "rejected";

      await request.save();

      res.status(200).json({
        message:
          "Transport request rejected",
      });
    } catch (error) {
      console.error(
        "Reject Transport Request Error:",
        error.message
      );

      res.status(500).json({
        message:
          "Server error while rejecting transport request",
      });
    }
  };

// UPDATE DELIVERY STATUS
const updateTransportStatus =
  async (req, res) => {
    try {
      if (
        req.user.role !==
        "transportProvider"
      ) {
        return res.status(403).json({
          message:
            "Only transport providers can update delivery status",
        });
      }

      const {
        deliveryStatus,
      } = req.body;

      const allowedStatuses = [
        "pickup_pending",
        "picked_up",
        "in_transit",
        "delivered",
      ];

      if (
        !allowedStatuses.includes(
          deliveryStatus
        )
      ) {
        return res.status(400).json({
          message:
            "Invalid delivery status",
        });
      }

      const request =
        await TransportRequest.findOne({
          _id: req.params.id,
          provider: req.user.id,
        });

      if (!request) {
        return res.status(404).json({
          message:
            "Transport assignment not found",
        });
      }

      request.deliveryStatus =
        deliveryStatus;

      if (
        deliveryStatus === "delivered"
      ) {
        request.status =
          "completed";

        await Vehicle.findByIdAndUpdate(
          request.vehicle,
          {
            status: "available",
          }
        );

        await Order.findByIdAndUpdate(
          request.order,
          {
            deliveryStatus:
              "delivered",
          }
        );
      } else if (
        deliveryStatus === "in_transit"
      ) {
        await Order.findByIdAndUpdate(
          request.order,
          {
            deliveryStatus:
              "in_transit",
          }
        );
      }

      await request.save();

      res.status(200).json({
        message:
          "Delivery status updated successfully",
        request,
      });
    } catch (error) {
      console.error(
        "Update Transport Status Error:",
        error.message
      );

      res.status(500).json({
        message:
          "Server error while updating delivery status",
      });
    }
  };

module.exports = {
  createTransportRequest,
  getFarmerTransportRequests,
  getProviderRequests,
  getProviderAssignments,
  acceptTransportRequest,
  rejectTransportRequest,
  updateTransportStatus,
};